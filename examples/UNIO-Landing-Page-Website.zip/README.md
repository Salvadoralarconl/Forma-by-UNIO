# UNIO — A little more connected

Exported with Forma by UNIO.

Open **Open-preview.html** directly for an offline preview, with no installation or build. Keep site.css and public/assets beside it. All active pages are stacked in their design order; internal links scroll to page or section anchors. Archived pages are omitted.

Editable React source is in src/. Install Node.js, run npm install once, then npm run dev. Run npm run build for a deployable dist directory. React source and standalone preview share the same renderer and styles. No account, API or publishing service is required.

## Limits

Free placement preserves fixed pixel coordinates and page dimensions; it is **not responsive**. Flow layouts retain their flex rules within the exported page width. Breakpoint overrides, tokens, components, annotations, editor state and custom scripts are not website behavior. Only declared http/https links and internal page/section anchors are exported. Imported icon vectors contain validated paths only. Local system font availability can affect text wrapping. This export includes raster assets, not remote dependencies for its standalone preview. npm installation may need internet or a populated local cache.

Review your rights to imported images and icon packs before distributing. See LICENSES/.
