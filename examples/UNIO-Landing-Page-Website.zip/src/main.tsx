import React from 'react';
import {createRoot} from 'react-dom/client';
import {Site} from './export/Site';
import project from './project.json';
import type {Project} from './domain/model';
import './site.css';
createRoot(document.getElementById('root')!).render(<Site project={project as Project}/>);
